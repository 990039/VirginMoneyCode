//
//  RoomsListViewModel.swift
//  VirginMoneyAssignment
//
//  Created by Prasad.ravella on 19/09/21.
//

import Foundation
class RoomsListViewModel {
    var room: [Room]?
func fetchRooms(
    _ urlString: String,
    result: @escaping (Swift.Result<Rooms, Error>) -> Void
)  {
    
    NetworkLayer.shared.fetchData(urlString){
        res in
        switch res{
        case .failure(let err):
            result(.failure(err))
        case .success(let response):
            do {
                guard let json = try JSONSerialization.jsonObject(with: response.1, options: []) as? [[String: Any]] else {
                    result(.failure(NetworkError.formatEror))
                    return
                }
                var rooms = Rooms()
                rooms.room = []
                for jsonObj in json {
                    guard let room = Room(json: jsonObj) else {continue}
                    rooms.room?.append(room)
                }
                result(.success(rooms))
            } catch {
                result(.failure(error))
            }
        }
    }
}
    // get number of rows for tableview
    func getnumberofRows()-> Int {
        guard let count = room?.count else {
            return 0
        }
        return count
    }
// get person
    func getPersonItemFirIndexPath(inexPath: Int)-> Room {
        return (room?[inexPath])!
    }
}
