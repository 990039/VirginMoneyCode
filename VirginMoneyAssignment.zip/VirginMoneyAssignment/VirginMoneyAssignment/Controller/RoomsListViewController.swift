//
//  RoomsListViewController.swift
//  VirginMoneyAssignment
//
//  Created by Prasad.ravella on 19/09/21.
//

import UIKit

class RoomsListViewController: UIViewController {
    var viewModel = RoomsListViewModel()

    @IBOutlet weak var roomsTableView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationItem.title = "Rooms"
        let textAttributes = [NSAttributedString.Key.foregroundColor:UIColor.white]
        navigationController?.navigationBar.titleTextAttributes = textAttributes
        roomsTableView.tableFooterView = UIView()
        roomsTableView.reloadData()
        viewModel.fetchRooms("https://5f7c2c8400bd74001690a583.mockapi.io/api/v1/rooms"){
            result in
            switch result {
            case .success(let rooms):
                self.viewModel.room = rooms.room
                DispatchQueue.main.async {
                    self.roomsTableView.reloadData()
                }
            case .failure(let error):
                print(error.localizedDescription)
            }
        }

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
extension RoomsListViewController: UITableViewDelegate, UITableViewDataSource {
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return viewModel.getnumberofRows()
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if let cell = tableView.dequeueReusableCell(withIdentifier: "RoomsListTableViewCell", for: indexPath) as? RoomsListTableViewCell {
            //cell.titleLable.text = dashBoarditems[indexPath.row]
            cell.selectionStyle = .none
            let room = viewModel.getPersonItemFirIndexPath(inexPath: indexPath.row)
            if let name = room.name {
                cell.nameLbl.text = "\(name)"
            }
            if let createdAt = room.createdAt {
                cell.createdByLbl.text = "CreatedAt : \(createdAt.getformatedDate())"
            }
            if let maxOccupancy = room.maxOccupancy {
                cell.maxOccupancyLbl.text = "MaxOccupancy : \(maxOccupancy)"
            }
            if let occupied = room.isOccupied {
                if occupied == true {
                    cell.occupiedLbl.text = "Occupied"
                    cell.occupiedLbl.textColor = .red
                } else {
                    cell.occupiedLbl.text = "Not Occupied"
                    cell.occupiedLbl.textColor = .green

                }
            }
            return cell
        }
        return UITableViewCell()
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 125
    }
   
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        self.performSegue(withIdentifier: "ShowTaskDetails", sender: self)
    }
    
}
