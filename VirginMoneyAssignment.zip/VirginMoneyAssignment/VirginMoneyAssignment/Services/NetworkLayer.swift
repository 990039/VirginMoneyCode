//
//  NetworkLayer.swift
//  VirginMoneyAssignment
//
//  Created by Prasad.ravella on 19/09/21.
//

import Foundation
class NetworkLayer {
    static var shared: NetworkLayer = NetworkLayer()

    func fetchData(
        _ urlString: String,
        result: @escaping (Swift.Result<(HTTPURLResponse, Data), Error>) -> Void
    ){
        URLSession.shared.dataTask(with: URL(string: urlString)!){
            data, response, error in
            if let error = error {
                result(.failure(error))
                return
            }
            guard let httpURLResponse = response as? HTTPURLResponse,
                  httpURLResponse.statusCode == 200,
                  let data = data
            else {
                let error = NetworkError.formatEror
                result(.failure(error))
                return
            }
            result(.success((httpURLResponse, data)))
        }.resume()
    }
}
