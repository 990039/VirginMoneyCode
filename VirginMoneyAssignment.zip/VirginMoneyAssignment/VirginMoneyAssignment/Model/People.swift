//
//  People.swift
//  VirginMoneyAssignment
//
//  Created by Prasad.ravella on 19/09/21.
//

import Foundation
struct People {
    var people: [Person]?
}

struct Person: JSONCodable {
    /*
     {
         "avatar": "https://randomuser.me/api/portraits/women/13.jpg",
         "phone": "(927) 840-0095 x2527",
         "firstName": "Maybell",
         "id": "1",
         "longitude": 139.6922,
         "favouriteColor": "#122a33",
         "email": "Izaiah.Little@hotmail.com",
         "jobTitle": "Customer Markets Architect",
         "createdAt": "2020-12-14T11:24:20.999Z",
         "latitude": 35.6897,
         "lastName": "Durgan"
       }
     */
    var avatar: String?
    var phone: String?
    var firstName: String?
    var id: String?
    var longitude: Double?
    var favouriteColor: String?
    var email: String?
    var jobTitle: String?
    var createdAt: String?
    var latitude: Double?
    var lastName: String?
}
