//
//  JSONCodable.swift
//  VirginMoneyAssignment
//
//  Created by Prasad.ravella on 19/09/21.
//

import Foundation
/// This protocol helps in definng the models and helps in creating codable models in a generic way
protocol JSONCodable: Codable {
    typealias JSON = [String : Any]
    
    func toDictionary() -> JSON?
    func toJSONString() -> String?
    init?(json: JSON)
}

extension JSONCodable {
    
    func toDictionary() -> JSON? {
        // Encode the data
        if let jsonData = try? JSONEncoder().encode(self),
            // Create a dictionary from the data
            let dict = try? JSONSerialization.jsonObject(with: jsonData, options: []) as? JSON {
            return dict
        }
        return nil
    }
    
    //encode Model to JSONString
    func toJSONString() -> String?{
        // Encode the data
        if let jsonData = try? JSONEncoder().encode(self){
            // Create a dictionary from the data
            return String(data: jsonData, encoding: .utf8)
        }
        return nil
    }
    
    //Decode from Dictionary
    init?(json: JSON) {
        do {
            let data = try JSONSerialization.data(withJSONObject: json, options: [])
            let object = try JSONDecoder().decode(Self.self, from: data)
            self = object
        } catch  {
            return nil
        }
    }
}
