//
//  URL+Extensions.swift
//  VirginMoneyAssignment
//
//  Created by Prasad.ravella on 19/09/21.
//

import Foundation
extension URL {
    static func forPeopleList() -> URL? {
        return URL(string: "https://5f7c2c8400bd74001690a583.mockapi.io/api/v1/people")
    }
    static func forRoomsList() -> URL? {
        return URL(string: "https://5f7c2c8400bd74001690a583.mockapi.io/api/v1/rooms")
    }
}
