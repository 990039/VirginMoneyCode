//
//  String+Extensions.swift
//  VirginMoneyAssignment
//
//  Created by Prasad.ravella on 21/09/21.
//

import Foundation
extension String {
    
    func getformatedDate()-> String {
        return self.components(separatedBy: "T").first ?? ""
    }
    
}
